import BacklogAssistant from "../components/BacklogAssistant";

export default function Home() {
  return (
    <div>
      <BacklogAssistant />
    </div>
  );
}